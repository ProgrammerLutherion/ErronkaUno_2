﻿namespace ErronkaUno_2_KP
{


    partial class ErronkaUno_2DataSet
    {
        partial class BezeroRelacionDataTable
        {
        }

        partial class BezeroDineroDataTable
        {
        }
    }
}

namespace ErronkaUno_2_KP.ErronkaUno_2DataSetTableAdapters
{
    partial class SalmentakHileroKantitateaTableAdapter
    {
    }

    partial class BezeroRelacionTableAdapter
    {
    }

    partial class BezeroCantidadTableAdapter
    {
    }

    public partial class BezeroDineroTableAdapter
    {
    }
}
